Rafael Eyng e Rafael Eyng - TGA-1 e TGA-2

Codificação Elias-Gamma e Golomb

O projeto é constituído pelas seguintes classes:

CodeMethod - Interface dos métodos de codificação
AbstractCode - Implementa alguns métodos do CodeMethod
Golomb - Extende o AbstractCode, fazendo com que uma instância desta utilize a codificação Golomb. O inteiro definido para a codificação foi 4.
EliasGamma - O mesmo que a classe Golomb, porém para Elias-Gamma
Codec - Classe que trabalha com o read e write dos arquivos
FakeLogarithm - Classe de apoio à EliasGamma, apenas para saber quantas vezes um número é divisível por 2.
Main - Interação com o usuário

Além das classes, nesse zip há um .jar, que pode ser executado por linha de comando.

Será pedido o caminho do arquivo que é desejado a codificação/decodificação.

Após isso, se é para codificar/decodificar e qual o método que deve ser usado.

O projeto completo encontra-se em https://github.com/RafaelCopat/TGA-T1 . Lá, é possível encontrar também as classes de teste que foram usadas para fazer o trabalho.
